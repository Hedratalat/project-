import 'package:flutter/material.dart';
import 'package:project/change_password.dart';
import 'package:project/services.dart';

class LoginScreen extends StatefulWidget {
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  var userController= TextEditingController();

  var passwordController= TextEditingController();

  bool _isPassword = true;

  Color mainColor = Color(0xFF5B8AB0);
  Color backgroundColor = Color(0xFFF5F5F5);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: mainColor, iconTheme: IconThemeData(
        color: Colors.white,),
        title: Text('Login', style: TextStyle(
          color: Colors.white,),
        ),
      ),

      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Image.asset('images/login.png'),
                Text(
                  'Welcome Back',
                  style: TextStyle(
                    fontSize: 47.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'welcome back we missed you',
                  style: TextStyle(
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: 25.0,),
                TextFormField(
                  controller:userController ,
                  onFieldSubmitted: (value){
                    print(value);
                  },
                  decoration: InputDecoration(
                    labelText: 'User Id',
                    prefixIcon: Icon(Icons.person),
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20.0,),
                TextFormField(
                  controller: passwordController,
                  obscureText: _isPassword,
                  onFieldSubmitted: (value){
                    print(value);
                  },
                  decoration: InputDecoration(
                    labelText: 'Password',
                    prefixIcon: Icon(Icons.key),
                    suffixIcon: togglePaswword(),
                    border: OutlineInputBorder(),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ChangePassword()),
                        );
                      },
                      child:
                      Text(
                        'Forgot Password?',
                        style: TextStyle(
                          color: Colors.grey[700],
                        ),
                      ),
                    ),],
                ),
                SizedBox(height: 10.0,),

                Container(
                  width: double.infinity,
                  color: mainColor,
                  child: MaterialButton(onPressed: ()
                  {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) =>  ServicesScreen ()),
                    );
                    print(userController.text);
                    print(passwordController.text);
                  },
                    child: Text('Login',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20.0,
                      ),),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget togglePaswword() {
    return IconButton(onPressed: () {
      setState(() {
        _isPassword = !_isPassword;
      });
    }, icon: _isPassword ? Icon(Icons.visibility_off) : Icon(Icons.visibility),
      color: Colors.grey,);
  }


}