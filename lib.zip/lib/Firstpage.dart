import 'package:flutter/material.dart';
import 'package:project/Register.dart';
import 'package:project/Services.dart';
import 'package:project/login.dart';


class Firstpage extends StatelessWidget {
  @override
  Color mainColor = Color(0xFF5B8AB0);
  Color backgroundColor = Color(0xFFF5F5F5);
  Color textColor = Color(0xFF294964);
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Home Page',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Image.asset('images/home0.png'),
            // SizedBox(height: 10),
            Image.asset('images/firstpage.gif'),
            SizedBox(height: 50), // Adds some space between the image and the buttons

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => LoginScreen()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    primary: mainColor,
                  ),
                  child: Text('Login',style:TextStyle(color: Colors.white),
                  ),
                ),
                SizedBox(width: 40), // Adds some space between the buttons
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Register()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    primary: mainColor,
                  ),
                  child: Text('Sign Up',style:TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}